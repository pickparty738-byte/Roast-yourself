# Roast-yourself
Flask-based AI chatbot that delivers savage Urdu roasts. Includes voice input/output, dark mode, chat saving, and premium unlock features.
